/*
Program  - A Queue of peoples waiting at star cineplex ticket counter,
Author   - MD AMINUL ISLAM
Language - C Language
Date     - 03/12/2018 (dd/mm/yyyy)
*/
#include<stdio.h>
#define MAXSIZE 5

struct Customer     //using logical structures ensures that the flow of control is clear
{
    char name[400];
    char contact_no[400];

}*store,*store1;  //Pointers are used to store dynamically allocated blocks of memory
int front=0, rear=-1;
char dataQueue[MAXSIZE][1000];
char dataQueue1[MAXSIZE][1000];

int main()      //Declare the default function to perform the Queue
{
    struct Customer customer;
    int choice;
    printf("===========> Assignment: Data Structure <=============\n\n");
    printf("\n 1 - Enqueue");
    printf("\n 2 - Dequeue");
    printf("\n 3 - Display");
    printf("\n 4 - Exit");

    while (1)        // Using the switch case to show the order
    {
        printf("\n Enter Your choice  :-> ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            printf("Enter Customer Name:");
            scanf("%s",&customer.name);
            printf("Enter Customer ContactNo:");
            scanf("%s",&customer.contact_no);
            enqueqe(customer);
            break;
        case 2:
            dequeue();
            break;
        case 3:
            display();
            break;
        case 4:
            exit(0);
            break;
        default :
            printf(" Wrong choice, Please enter correct choice  ");
            break;
        }
    }
}

void enqueqe(struct Customer customer) //Used enqueue function to store data in memory
{
    rear++;
    printf("\n");
    strcpy(dataQueue[rear],customer.name);
    strcpy(dataQueue1[rear],customer.contact_no);
}
void display() ////Used display function to show data from the Queue

{
    int i;
    if( front>rear )
    {
        printf("Empty /n");
    }
    else
    {

        for( i=front; i<=rear; i++)
        {
            printf("Details = : %s\t%s\n",dataQueue[i],dataQueue1[i]);
        }
    }
}
void dequeue()      //Used Dequeue to remove data form the memory
{
    if( front>rear )
    {
        printf("Sorry queue is empty!!!/n");
    }
    else
    {
        printf("Remove data is: %s\t%s\n",dataQueue[front],dataQueue1[front]);
        front++;
    }

}
