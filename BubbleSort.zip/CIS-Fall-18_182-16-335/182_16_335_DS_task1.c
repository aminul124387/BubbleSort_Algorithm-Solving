/*
Program  - Array Sorting using Bubble Sort for Ascending and descending
Author   - MD AMINUL ISLAM
Language - C Language
Date     - 03/12/2018 (dd/mm/yyyy)
*/

#include <stdio.h>  //including stdio.h for printf and other functions
#define Max 10
void ascending(int arr[Max],int n);
void descending(int arr[Max],int n);
int a[10];
int main()           //default function for call
{
    int n,i,j;
    printf("==============>> Data Structure <<==========\n\n");
    printf("==============>> Bubble Sort <<==========\n\n\n");
    printf("Enter the Array size that want to?: ");
    scanf("%d",&n);

    for(i=1; i<=n; i++)
    {
        printf("Elements number: %d\t",i);
        scanf("%d",&a[i]);
    }
     printf("\nThe given array is:\t");
     for (i = 1; i <=n; i++) {
      printf("%d ", a[i]);
     }
    int choice;
    printf("\n\n==============>> Enter Your Choice <<==========\n\n");
    printf("\n 1 - Ascending");
    printf("\n 2 - Descending");
    printf("\n 3 - Exit \n\n");
    printf("==============>> Output Here <<==========\n\n");

    while (1)   /* Use Switch Case for choice or give order for
                sorting ascending and descending*/
    {
        printf("\n Enter Your choice  :-> ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            ascending(a,n);
            break;
        case 2:
            descending(a,n);
            break;
        case 3:
            exit(0);
            break;
        default :
            printf(" Wrong choice, Please enter correct choice  ");
            break;
        }
    }

    return 0;     //returning 0 status to system
}

void ascending(int a[],int n)         //Create function for ascending order value return
{
    int i,j;

    for (int i = 1; i <=n; i++)        //Loop for ascending ordering
    {
        for (int j = 1; j <=n; j++)   //Loop for comparing other values
        {
            if (a[j] > a[i])          //Comparing other array elements
            {
                int tmp = a[i];       //Using temporary variable for storing last value
                a[i] = a[j];          //replacing value
                a[j] = tmp;           //storing last value
            }
        }
    }

    printf("\n\nData arranged in Ascending ordered: ");      //Printing message
    for (int i = 1; i <=n; i++)      //Loop for printing array data after sorting
    {
        printf(" %d ", a[i]);
    }
}



void descending(int a[],int n)    //Create function for descending order value return
{
    int i,j;
    for (int i = 1; i <=n; i++)     //Loop for descending ordering
    {
        for (int j = 1; j <=n; j++)  //Loop for comparing other values
        {
            if (a[j] < a[i])        //Comparing other array elements
            {
                int tmp = a[i];      //Using temporary variable for storing last value
                a[i] = a[j];       //replacing value
                a[j] = tmp;      //storing last value
            }
        }
    }
    printf("\n\nData Arranged in Descending ordered : ");   //Printing message
    for (int i = 1; i <=n; i++)   //Loop for printing array data after sorting
    {
        printf(" %d ", a[i]); //Printing data
    }
}


